/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking.management;

/**
 *
 * @author aditya
 */
public class node {
     String name;
    String no;
    String emailid;
    String etime;
    String dtime;
    String payt;
    int ammount;
    String date;
    int pn;
   
    node next;
}
